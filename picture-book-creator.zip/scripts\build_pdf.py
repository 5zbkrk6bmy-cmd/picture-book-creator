#!/usr/bin/env python3
"""
Picture Book PDF Builder

将绘本插图合成为 PDF。

核心原则：
- 每页 PDF 尺寸 = 图片原始像素尺寸，不做 A5 适配，不做固定版面
- 不做任何缩放、裁剪、留白，图片完整填满整页
- 支持封面和封底
- 自动补空白页，确保总页数为 4 的倍数（双面打印装订友好）

用法：
    python build_pdf.py --pages-dir ./pages --output ./output/book.pdf --title "小兔子的冒险"

    # 指定封面和封底
    python build_pdf.py --pages-dir ./pages --output ./output/book.pdf \
        --cover ./pages/cover.png --back-cover ./pages/back_cover.png \
        --title "小兔子的冒险"

    # 使用 JSON 配置文件
    python build_pdf.py --config ./book_config.json
"""

import argparse
import json
import os
import sys
from pathlib import Path

# Windows UTF-8 支持
if sys.platform == "win32":
    try:
        if hasattr(sys.stdout, "reconfigure"):
            sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        if hasattr(sys.stderr, "reconfigure"):
            sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

try:
    from PIL import Image
    from reportlab.lib.utils import ImageReader
    from reportlab.pdfgen import canvas
except ImportError:
    print("Error: Required packages not installed.")
    print("Please run: pip install Pillow reportlab")
    sys.exit(1)


# ============================================================
# PDF 生成
# ============================================================

def images_to_pdf(pages, output_path, title="Picture Book"):
    """
    将页面图片列表合成为 PDF。

    核心原则：每页尺寸 = 图片原始像素尺寸（1:1 映射）。
    不做缩放、不做裁剪、不做留白，图片完整填满整页。

    自动补空白页使总页数为 4 的倍数。

    Args:
        pages: PIL Image 对象列表
        output_path: 输出 PDF 路径
        title: PDF 标题元数据
    """
    # 补空白页到 4 的倍数
    if not pages:
        print("Error: No pages to assemble.")
        sys.exit(1)

    # 获取第一张图片的尺寸作为空白页尺寸
    first_w, first_h = pages[0].size
    remainder = len(pages) % 4
    if remainder != 0:
        blank_count = 4 - remainder
        blank = Image.new("RGB", (first_w, first_h), (255, 255, 255))
        for _ in range(blank_count):
            pages.append(blank)
        print(f"  + Added {blank_count} blank page(s) for print alignment (total: {len(pages)} pages)")

    c = None

    for i, page_img in enumerate(pages):
        img_width, img_height = page_img.size

        # 直接使用图片原始像素作为 PDF 页面尺寸（1点 = 1像素，即 72 DPI）
        # 这样图片在 PDF 中以原始像素 1:1 渲染，不做任何缩放
        page_w_pt = float(img_width)
        page_h_pt = float(img_height)

        if i == 0:
            c = canvas.Canvas(output_path, pagesize=(page_w_pt, page_h_pt))
            c.setTitle(title)
            c.setAuthor("Picture Book Creator")
            c.setSubject(title)
        else:
            c.showPage()
            c.setPageSize((page_w_pt, page_h_pt))

        # 图片直接绘制到 (0, 0)，宽高 = 页面宽高，完整填满
        img_reader = ImageReader(page_img)
        c.drawImage(
            img_reader,
            0, 0,
            width=page_w_pt,
            height=page_h_pt,
            preserveAspectRatio=False,  # 完整填满，不做留白
        )

    c.save()
    print(f"  PDF saved: {output_path}")


# ============================================================
# 文件发现与排序
# ============================================================

def discover_pages(pages_dir, cover_path=None, back_cover_path=None):
    """
    自动发现页面图片文件。

    支持的命名模式：
    - page_01.png, page_02.png, ...
    - cover.png, back_cover.png
    - 任何按数字排序的图片文件

    Returns:
        list of Path objects
    """
    pages_dir = Path(pages_dir)
    if not pages_dir.exists():
        raise FileNotFoundError(f"Pages directory not found: {pages_dir}")

    result = []

    # 封面
    if cover_path and Path(cover_path).exists():
        result.append(Path(cover_path))
    else:
        cover_candidates = ["cover.png", "cover.jpg", "cover.jpeg", "front_cover.png"]
        for name in cover_candidates:
            candidate = pages_dir / name
            if candidate.exists():
                result.append(candidate)
                break

    # 正文页面
    image_extensions = {".png", ".jpg", ".jpeg"}
    exclude_names = {"cover", "back_cover", "front_cover"}

    page_files = []
    for f in sorted(pages_dir.iterdir()):
        if f.suffix.lower() in image_extensions and f.stem not in exclude_names:
            page_files.append(f)

    # 按文件名中的数字排序
    def extract_number(path):
        import re
        numbers = re.findall(r"\d+", path.stem)
        return int(numbers[0]) if numbers else 0

    page_files.sort(key=extract_number)

    for pf in page_files:
        result.append(pf)

    # 封底
    if back_cover_path and Path(back_cover_path).exists():
        result.append(Path(back_cover_path))
    else:
        back_candidates = ["back_cover.png", "backcover.png", "back_cover.jpg", "back_cover.jpeg"]
        for name in back_candidates:
            candidate = pages_dir / name
            if candidate.exists():
                result.append(candidate)
                break

    return result


# ============================================================
# JSON 配置模式
# ============================================================

def load_config(config_path):
    """加载 JSON 配置文件。"""
    with open(config_path, "r", encoding="utf-8") as f:
        return json.load(f)


def process_from_config(config):
    """从 JSON 配置执行 PDF 构建。"""
    pages_dir = config.get("pages_dir", "./pages")
    output = config.get("output", "./output/book.pdf")
    title = config.get("title", "Picture Book")
    cover = config.get("cover", None)
    back_cover = config.get("back_cover", None)

    os.makedirs(os.path.dirname(output) or ".", exist_ok=True)

    page_entries = discover_pages(pages_dir, cover, back_cover)

    pages = []
    for img_path in page_entries:
        print(f"  Processing: {img_path.name}")
        img = Image.open(img_path).convert("RGB")
        pages.append(img)

    images_to_pdf(pages, output, title)
    print(f"\nDone! PDF created with {len(page_entries)} content pages.")


# ============================================================
# 主函数
# ============================================================

def main():
    parser = argparse.ArgumentParser(
        description="Picture Book PDF Builder - Original-size pages, no cropping/scaling",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Basic usage - auto-discover pages
  python build_pdf.py --pages-dir ./pages --output ./book.pdf --title "My Book"

  # With cover and back cover
  python build_pdf.py --pages-dir ./pages --output ./book.pdf \\
    --cover ./pages/cover.png --back-cover ./pages/back_cover.png

  # From JSON config
  python build_pdf.py --config ./book_config.json
        """,
    )

    parser.add_argument("--pages-dir", "-p", help="Directory containing page images")
    parser.add_argument("--output", "-o", help="Output PDF path")
    parser.add_argument("--title", "-t", default="Picture Book", help="Book title (for PDF metadata)")
    parser.add_argument("--cover", "-c", help="Path to cover image")
    parser.add_argument("--back-cover", "-b", help="Path to back cover image")
    parser.add_argument("--config", help="Path to JSON config file")

    args = parser.parse_args()

    # JSON 配置模式
    if args.config:
        if not os.path.exists(args.config):
            print(f"Error: Config file not found: {args.config}")
            sys.exit(1)
        config = load_config(args.config)
        process_from_config(config)
        return

    # 命令行模式
    if not args.pages_dir or not args.output:
        parser.print_help()
        print("\nError: --pages-dir and --output are required (unless using --config)")
        sys.exit(1)

    if not os.path.exists(args.pages_dir):
        print(f"Error: Pages directory not found: {args.pages_dir}")
        sys.exit(1)

    print(f"Building picture book PDF...")
    print(f"  Pages dir: {args.pages_dir}")
    print(f"  Output:    {args.output}")
    print(f"  Title:     {args.title}")
    print(f"  Mode:      Original size (no scaling/cropping/padding)")
    print()

    os.makedirs(os.path.dirname(os.path.abspath(args.output)), exist_ok=True)

    # 发现页面
    page_entries = discover_pages(args.pages_dir, args.cover, args.back_cover)
    print(f"  Found {len(page_entries)} page(s)")

    if not page_entries:
        print("Error: No page images found in the directory.")
        print("Expected files like: cover.png, page_01.png, page_02.png, ...")
        sys.exit(1)

    # 加载所有图片
    pages = []
    for i, img_path in enumerate(page_entries):
        role = "Cover" if i == 0 else ("Back Cover" if i == len(page_entries) - 1 else f"Page {i}")
        print(f"  Processing {role}: {img_path.name}", end="")
        try:
            img = Image.open(img_path).convert("RGB")
            w, h = img.size
            print(f" ({w}x{h}px)")
            pages.append(img)
        except Exception as e:
            print(f" WARNING: {e}")

    if not pages:
        print("Error: No pages were successfully loaded.")
        sys.exit(1)

    # 生成 PDF
    images_to_pdf(pages, args.output, args.title)

    print(f"\nDone! PDF created with {len(pages)} pages.")
    print(f"  File: {os.path.abspath(args.output)}")


if __name__ == "__main__":
    main()
