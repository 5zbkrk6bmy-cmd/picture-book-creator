# Seedream 图片生成 — 绘本专用集成指南

> 本文档整合自 Seedream 图片生成 Skill，专为绘本创作场景优化。
> Seedream 基于火山引擎方舟大模型服务平台，支持文生图、图生图、组图生成等。

## 前置要求

- **环境变量**：`ARK_API_KEY`（火山引擎 API Key）和推理接入点 ID（格式 `ep-xxxxxxxx`）
- **配置方式**：从项目 `.env` 文件读取，绝不在 Skill 中硬编码
  - `.env` 文件格式：
    ```
    ARK_API_KEY=ark-xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx
    Model ID/接入点 ID(model-name): ep-xxxxxxxx-xxxxxxxx
    ```
- **依赖 Skill**：`seedream-image-gen`（从 SkillHub 安装，可选）

> ⚠️ **仅在需要图生图/参考图/组图模式时才使用 Seedream**。纯文生图请优先使用内置 `image_gen` 工具。

## 调用方式

### 方式 1：通过 WorkBuddy 内置 image_gen 工具（默认，第一优先级）

WorkBuddy 内置了 `image_gen` 工具，可直接生成图片：

```
调用 image_gen 工具，传入 prompt、size（2048x1536 或更大）、quality 等参数。
```

**绘本创作中优先使用此方式**，无需额外配置 API Key，开箱即用。

### 方式 2：通过 Seedream 5.0 API 直接调用（图生图/组图模式）

当需要参考照片保持角色一致性时，直接调用火山方舟 API：

**API Endpoint**：`https://ark.cn-beijing.volces.com/api/v3/images/generations`

**请求格式**（OpenAI 兼容）：
```json
{
  "model": "{推理接入点 ID，如 ep-m-20260428164638-f28gd}",
  "prompt": "{英文提示词}",
  "size": "2048x2048",
  "n": 1,
  "ref_image": "{参考图片的 base64 编码字符串}",
  "sequential_image_generation": "auto",
  "sequential_image_generation_options": {"max_images": 4}
}
```

**响应格式**：
```json
{
  "data": [
    {"url": "https://ark-acg-cn-beijing.tos-cn-beijing.volces.com/...", "size": "2048x2048"},
    {"url": "...", "size": "2048x2048"}
  ]
}
```

**关键参数说明**：

| 参数 | 类型 | 说明 | 注意事项 |
|------|------|------|----------|
| `model` | string | 推理接入点 ID（`ep-xxxxxxxx`），**不是模型名** | ❌ 填 `doubao-seedream-5-0-lite` 会报错 |
| `ref_image` | string | 参考图片的 **base64** 编码 | ✅ 支持 base64；❌ 不支持本地文件路径 |
| `image` | string | 参考图片的 **URL** | ❌ 不支持 base64，仅支持 URL |
| `sequential_image_generation` | string | `"auto"` 启用组图，`"disabled"` 单图 | 组图模式一次返回多张图 |
| `sequential_image_generation_options` | object | `{"max_images": N}`，N ≤ 9 | 建议 ≤ 4 以获得最佳一致性 |
| `size` | string | `"2048x2048"` | ⚠️ Seedream 5.0 要求 **≥3686400 像素**（2048x2048=4194304 ✅；2048x1536=3145728 ❌） |
| `response_format` | string | `"url"`（默认）或 `"b64_json"` | URL 格式更高效，24 小时有效 |

**认证方式**：
```
Authorization: Bearer {ARK_API_KEY}
```

### 方式 3：通过已安装的 Seedream Skill（备选）

当环境中已安装 `seedream-image-gen` Skill 时，可调用其脚本：

```bash
python3 {seedream_base_dir}/scripts/seedream.py [参数]
```

其中 `{seedream_base_dir}` 通常是 `~/.workbuddy/skills/seedream-image-gen`。

## Seedream 命令行参数速查

| 参数 | 简写 | 说明 | 默认值 |
|------|------|------|--------|
| --api-key | -k | API Key | 环境变量 ARK_API_KEY |
| --prompt | -p | 提示词（英文更佳） | 必填 |
| --model | -m | 模型 (5.0-lite/4.5/4.0) | 5.0-lite |
| --image | -i | 输入图片（图生图用） | - |
| --size | -s | 图像尺寸 | 2K |
| --output-format | -f | 输出格式 (png/jpeg) | png |
| --watermark | -w | 添加水印 | False |
| --sequential | - | 启用组图模式 | False |
| --max-images | - | 组图最大张数 | 4 |
| --output | -o | 输出目录 | ~/Downloads |
| --proxy | -x | 代理地址 | - |

## 绘本专用参数配置

### 角色样卡生成

```bash
# 正方形，适合角色设定图
python3 {seedream_base_dir}/scripts/seedream.py \
  -p "{角色提示词}" \
  -s 2048x2048 \
  -o {output_dir}/characters
```

### 场景参考图

```bash
# 正方形或横向，适合场景设定
python3 {seedream_base_dir}/scripts/seedream.py \
  -p "{场景提示词}" \
  -s 2048x2048 \
  -o {output_dir}/scenes
```

### 绘本页面插图

```bash
# 横向比例，适合绘本跨页
python3 {seedream_base_dir}/scripts/seedream.py \
  -p "{页面提示词}" \
  -s 2048x1536 \
  -o {output_dir}/pages
```

### 封面插图

```bash
# 横向，封面
python3 {seedream_base_dir}/scripts/seedream.py \
  -p "{封面提示词}" \
  -s 2048x1536 \
  -o {output_dir}
```

### 封底插图

```bash
# 横向，封底
python3 {seedream_base_dir}/scripts/seedream.py \
  -p "{封底提示词}" \
  -s 2048x1536 \
  -o {output_dir}
```

## 批量生成策略

### 组图模式（连贯插画）

当需要生成风格连贯的多张插画时，使用组图模式：

```bash
# 生成 4 张连贯的绘本页面
python3 {seedream_base_dir}/scripts/seedream.py \
  -p "生成4张连贯的儿童绘本插画，{整体描述}，保持角色一致性和风格统一" \
  --sequential \
  --max-images 4 \
  -s 2048x1536 \
  -o {output_dir}/pages
```

注意：组图模式最多支持 4 张，超过 4 页需分批生成。

### 分批生成

对于 12+ 页的绘本，分批生成以保持风格一致性：

```bash
# 第 1 批：角色样卡 + 前 4 页
# 第 2 批：中间 4 页（可参考前一批的输出图）
# 第 3 批：最后 4 页 + 封底
```

使用 `--image` 参数传入参考图，保持角色一致性：

```bash
# 参考角色样卡生成页面
python3 {seedream_base_dir}/scripts/seedream.py \
  -p "{页面提示词}" \
  -i "{角色样卡路径}" \
  -s 2048x1536 \
  -o {output_dir}/pages
```

## 输出文件管理

- 输出文件名格式：`seedream_{timestamp}_{index}.{ext}`
- 生成后建议重命名为语义化文件名：

```
cover.png           # 封面
page_01.png         # 第 1 页
page_02.png         # 第 2 页
...
page_12.png         # 第 12 页
back_cover.png      # 封底
```

## 支持的模型

| 模型 | 别名 | 推荐用途 | 输出格式 |
|------|------|----------|----------|
| Seedream 5.0 lite | 5.0-lite | **绘本首选**，质量与速度平衡 | PNG |
| Seedream 4.5 | 4.5 | 更高画质 | JPEG |
| Seedream 4.0 | 4.0 | 基础使用 | JPEG |

**绘本推荐**：使用 5.0-lite，支持 PNG 输出（无损），适合后续 PDF 组装。

## 图像尺寸选项

> **绘本创作要求：所有图片尺寸必须 ≥2048px（短边至少 1536px）。**

| 预设 | 像素（约） | 推荐用途 |
|------|-----------|----------|
| 1K | 1024px | 快速预览（不推荐用于最终绘本） |
| 2K | 2048px | **最低标准** |
| 3K | 2848px | 高清 |
| 4K | 4096px | 超高清（生成较慢） |
| 自定义 | 如 2048x1536 | **绘本横向页面推荐** |

**推荐尺寸**：2048x1536（横向）或更大。PDF 按图片原始尺寸生成，不做缩放，因此图片越大打印效果越好。

## 提示词语言

Seedream 对英文提示词响应更佳。在绘本创作中：
- 所有提示词**使用英文构建**
- 提示词模板参考 `references/prompt-templates.md`
- 风格关键词参考 `references/prompt-templates.md` 中的风格词库

## 踩坑经验（实战总结）

以下经验来自实际调用 Seedream 5.0 API 的测试，避免重复踩坑：

### 1. model 参数必须填推理接入点 ID
- ❌ `"model": "doubao-seedream-5-0-lite"` → 报错 `model not found`
- ❌ `"model": "Doubao-Seedream-5.0-lite"` → 报错
- ✅ `"model": "ep-m-20260428164638-f28gd"` → 成功
- 推理接入点 ID 在火山方舟控制台创建，格式为 `ep-xxxxxxxx`

### 2. 图片尺寸必须 ≥ 3686400 像素
- ❌ `"size": "1024x1024"` → 报错 `image size must be at least 3686400 pixels`
- ❌ `"size": "2048x1536"` → 报错（2048×1536 = 3,145,728 < 3,686,400）
- ✅ `"size": "2048x2048"` → 成功（2048×2048 = 4,194,304）
- 如果需要横向比例，使用 `2048x2048` 生成后在提示词中指定构图方向

### 3. ref_image 接受 base64，image 仅接受 URL
- `"ref_image": "{base64字符串}"` → ✅ 图生图成功
- `"image": "{base64字符串}"` → ❌ 报错 `invalid url specified`
- `"image": "https://example.com/photo.jpg"` → ✅（如果有公网 URL）
- **推荐使用 `ref_image` + base64**，无需上传图片到公网

### 4. 组图模式 + 参考图可同时使用
- `sequential_image_generation: "auto"` + `ref_image` → ✅ 完全兼容
- 一次请求返回多张图，每张图的角色保持高度一致
- 建议每批 4 张以内，超过 4 张分批处理

### 5. API 响应返回 URL，非 base64
- 默认 `response_format: "url"`，返回临时 URL（24 小时有效）
- 必须及时下载到本地
- 如需 base64 格式，设置 `"response_format": "b64_json"`

### 6. API Key 与推理接入点的关系
- `ARK_API_KEY` 是账号级别的 API 密钥
- 推理接入点 ID 是某个模型实例的入口
- 同一个 API Key 可以访问该账号下的所有推理接入点
- 需要先在火山方舟控制台为 Seedream 模型创建推理接入点

## .env 文件配置模板

在绘本项目目录下创建 `.env` 文件：

```
ARK_API_KEY=ark-xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx
Model ID/接入点 ID(doubao-seedream-5-0-260128): ep-m-xxxxxxxx-xxxxxxxx
```

读取方式（Python）：
```python
def load_env(env_path):
    """从 .env 文件读取 ARK_API_KEY 和接入点 ID"""
    config = {}
    with open(env_path) as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith('#'):
                continue
            if '=' in line:
                key, value = line.split('=', 1)
                config[key.strip()] = value.strip()
    return config

# ARK_API_KEY
# 接入点 ID: config 中含有 "Model ID" 或 "ep-" 的值
```

## 图生图批量生成实战示例

以下是完整的 Python 调用示例，生成一组 4 张连贯绘本页面：

```python
import urllib.request, json, base64

api_key = "{从 .env 读取}"
endpoint = "{从 .env 读取，ep-xxx 格式}"

# 读取参考照片
with open("reference_photo.jpg", "rb") as f:
    ref_b64 = base64.b64encode(f.read()).decode()

# 组合提示词（4 页一起生成）
prompt = """Generate a set of 4 sequential watercolor illustrations:
Image 1: Baby Dada waking up in bed, morning sunlight, stretching.
Image 2: Baby Dada washing hands at sink, splashing water happily.
Image 3: Baby Dada eating breakfast in high chair, big smile.
Image 4: Baby Dada playing with colorful building blocks.
Keep the same baby character Dada with identical appearance across all images.
Big round face, big sparkling eyes, short black hair, rosy cheeks.
Watercolor illustration, hand-painted, soft warm colors."""

payload = json.dumps({
    "model": endpoint,
    "prompt": prompt,
    "size": "2048x2048",
    "n": 1,
    "ref_image": ref_b64,
    "sequential_image_generation": "auto",
    "sequential_image_generation_options": {"max_images": 4}
}).encode()

req = urllib.request.Request(
    "https://ark.cn-beijing.volces.com/api/v3/images/generations",
    data=payload,
    headers={
        "Content-Type": "application/json",
        "Authorization": f"Bearer {api_key}"
    }
)

resp = urllib.request.urlopen(req, timeout=300)
data = json.loads(resp.read().decode())

# 下载所有图片
for i, item in enumerate(data["data"]):
    urllib.request.urlretrieve(item["url"], f"page_{i+1:02d}.png")
    print(f"Saved page_{i+1:02d}.png")
```
