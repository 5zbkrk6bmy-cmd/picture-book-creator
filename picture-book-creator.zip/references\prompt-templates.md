# Seedream 插图提示词模板库

本文档为绘本创作提供标准化的 Seedream 图片生成提示词模板。所有提示词均以英文构建（Seedream 对英文提示词响应更佳），输出中文描述仅供参考。

## 通用结构

每个插图提示词遵循以下结构：

```
[主体描述] + [场景/环境] + [动作/情绪] + [风格修饰词] + [构图与留白指示]
```

## 角色设计提示词模板

### 模板 1: 角色全身设定图
```
Character design sheet of {角色名}, {动物/物体类型}, {颜色} colored, {体型描述}.
{标志性特征}, {性格相关的表情}.
Full body front view, clean white background.
{风格关键词}.
Simple shapes, rounded edges, child-friendly proportions.
Character design reference sheet style, multiple poses shown.
```

### 模板 2: 角色表情集
```
Expression sheet of {角色名}, showing 6 emotions:
happy, curious, sleepy, surprised, sad, excited.
{角色外观简述}.
Consistent character design, {风格关键词}.
White background, evenly spaced grid layout.
Each expression clearly different, suitable for children's book.
```

## 场景提示词模板

### 模板 3: 内景场景
```
{场景名}, {时间/光线描述}.
{主要元素}, {次要元素}, {装饰细节}.
{色调描述}, warm and cozy atmosphere.
{风格关键词}, soft lighting, no harsh shadows.
Leave the bottom 25% as soft gradient area for text.
Landscape composition, {构图关键词}.
```

### 模板 4: 外景场景
```
{场景名}, {天气/时间}.
{远景}, {中景元素}, {前景元素}.
{氛围描述}, {色调}.
{风格关键词}, dreamy atmosphere.
Leave the bottom 25% as soft gradient area for text.
Wide landscape composition, depth with layered elements.
```

## 页面插图提示词模板

### 模板 5: 单角色场景（最常用）
```
{角色名}, {角色外观描述}, {动作描述}.
{场景描述}, {环境细节}.
{情绪/表情}.
{风格关键词}, soft warm lighting, gentle colors.
务必把「{该页文字原文}」的文字嵌入图片中，渲染为可爱的圆角{文字颜色}字体，位于画面底部居中位置，带柔和文字阴影以确保可读性。文字区域使用柔和的{亮/暗}渐变背景。
Landscape orientation, {构图关键词}.
```

### 模板 5b: 单角色场景 — 双语版
```
{角色名}, {角色外观描述}, {动作描述}.
{场景描述}, {环境细节}.
{情绪/表情}.
{风格关键词}, soft warm lighting, gentle colors.
务必把「{第一语言文字}」和「{第二语言文字}」的文字嵌入图片中，分两行显示于画面底部居中位置：第一行{第一语言}（较大字号），第二行{第二语言}（较小字号）。使用可爱的圆角{文字颜色}字体，带柔和文字阴影，文字区域使用柔和渐变背景。
Landscape orientation, {构图关键词}.
```

### 模板 6: 双角色互动
```
{角色A} and {角色B} together, {互动描述}.
{角色A外观}, {角色B外观}.
{场景描述}.
{情感描述}, {风格关键词}.
Warm lighting, joyful atmosphere.
务必把「{该页文字原文}」的文字嵌入图片中，渲染为可爱的圆角{文字颜色}字体，位于画面底部居中位置，带柔和文字阴影，文字区域使用柔和渐变背景。
Center-focused composition, characters interacting naturally.
```

### 模板 7: 特写/情绪聚焦
```
Close-up of {角色名}, {情绪描述}.
{角色面部细节}.
{背景虚化描述}, blurred background.
{风格关键词}, soft focus, emotional.
Large face filling most of the frame.
务必把「{该页文字原文}」的文字嵌入图片中，渲染为可爱的圆角{文字颜色}字体，位于画面底部15%区域，带柔和文字阴影，文字区域尽量简洁。
Intimate composition, warm tones.
```

### 模板 8: 封面插图
```
Book cover illustration for a children's picture book.
务必把「{绘本标题}」的文字嵌入图片中，渲染为较大的可爱圆角{文字颜色}字体，位于画面顶部居中位置，带柔和装饰性文字阴影。
{主要角色} in the center, {角色外观描述}.
{场景描述}, magical/warm atmosphere.
{风格关键词}, rich colors, inviting composition.
Center composition, character facing forward with friendly expression.
Decorative border elements, {装饰元素}.
Vibrant yet soft, eye-catching for children.
```

### 模板 9: 封底插图
```
Back cover illustration for a children's picture book.
{场景描述}, peaceful/calm atmosphere.
{角色描述}, small figure in the scene.
{风格关键词}, muted soft colors.
Minimal composition, lots of negative space.
Leave center area empty for barcode and text.
Quiet, gentle ending mood.
No story text on back cover.
```

## 风格关键词库

### 水彩手绘风
```
watercolor illustration, hand-painted, soft brushstrokes, gentle color bleeding,
delicate textures, light and airy, pastel undertones, organic edges,
traditional watercolor technique, visible paper texture, warm and soft
```

### 蜡笔/粉笔涂鸦风
```
crayon drawing style, bold outlines, chunky strokes, waxy texture,
child-like drawing, bright saturated colors, rough edges, playful marks,
hand-drawn feel, naive art style, cheerful and bold
```

### 扁平卡通风
```
flat illustration, clean vector style, bold solid colors, smooth edges,
geometric shapes, simple shading, modern children's book illustration,
clear outlines, vibrant but not overwhelming, balanced composition
```

### 剪纸/拼贴艺术风
```
paper cut illustration, layered paper collage, visible paper edges,
textured surfaces, dimensional depth, mixed patterns,
craft-style art, tactile quality, handcrafted feel, warm and whimsical
```

### 柔和粉彩风
```
soft pastel illustration, macaron color palette, dreamy atmosphere,
gentle gradients, muted tones, airbrushed softness,
cotton candy colors, ethereal quality, light and fluffy
```

### 黑白线稿+局部上色
```
black and white line drawing with selective color accents,
ink illustration style, delicate hatching, minimal color pops,
mostly monochrome with one or two colored elements,
artistic and elegant, clean lines, sophisticated simplicity
```

## 角色一致性技巧

为确保同一角色在不同页面中保持视觉一致，每次提示词都应包含以下固定描述：

```
# 在每个含角色的提示词中都加入这段固定描述
{角色名}: {固定颜色}, {固定体型}, {标志性特征}, {固定表情风格}
```

示例：
```
Xiao Bai: a small white rabbit with big round eyes, pink inner ears,
a tiny cotton-ball tail, always looking curious with slightly tilted head
```

### 组图模式角色一致性（Seedream 5.0 API）

当使用 Seedream 5.0 的 `sequential_image_generation` 组图模式时，角色一致性由以下方式保证：

1. **参考照片**：将用户提供的角色照片作为 `ref_image` 传入，AI 会参考照片中的角色特征
2. **组合提示词**：在一条提示词中描述多页内容，明确要求保持角色一致
3. **固定角色描述**：每页描述中重复完全相同的角色外观描述

**组图模式提示词模板**：
```
Generate a set of {N} sequential watercolor illustrations:
Image 1: {角色名}, {角色固定外观}, {场景1}, {动作1}.
Image 2: {角色名}, {角色固定外观}, {场景2}, {动作2}.
Image 3: {角色名}, {角色固定外观}, {场景3}, {动作3}.
...
Keep the same {角色名} character with identical appearance across all images.
{风格关键词}, soft warm lighting, gentle colors.
```

> ⚠️ 组图模式每批最多 4 张（建议 3-4 张以获得最佳一致性），超过需分批。每批都传入相同的参考照片。

## 留白指示词

为确保文字可读性，根据文字位置选择留白指示：

```
# 文字在底部（最常用）
Leave the bottom 20% as a soft gradient space for text overlay,
keep the text area clean with minimal elements.

# 文字在顶部
Leave the top 20% as a soft light area for text,
keep the upper portion clean and simple.

# 文字在左侧
Keep the left 25% of the composition relatively clean for text placement,
character positioned on the right side.

# 文字分散在画面中
Use clean negative spaces within the composition for floating text placement,
avoid busy patterns in text areas.
```

## 提示词优化要点

1. **角色描述放前面**：AI 优先处理提示词开头的元素
2. **风格词放中间**：在场景和构图之间插入风格关键词
3. **文字嵌入放中间偏后**：在风格关键词之后、构图指示之前插入文字渲染指示
4. **技术指示放末尾**：构图、留白、尺寸等技术指示放在最后
5. **避免负面描述**：不说"不要..."，而是描述想要的正向效果
6. **控制复杂度**：1 岁绘本每页提示词控制在 100 词以内
7. **强调柔和**：为低龄儿童绘本，始终加入 soft/gentle/warm 等柔和修饰词
8. **文字必须原文嵌入**：页面文字以用户指定的语言原文写入提示词，使用 `务必把「...」的文字嵌入图片中` 强制指令格式

### image_gen vs Seedream 提示词差异

| 差异点 | image_gen（文生图） | Seedream 5.0（图生图） |
|--------|-------------------|----------------------|
| 提示词语言 | 英文更佳 | 英文更佳 |
| 尺寸参数 | `2048x1536` 可用 | **必须 ≥3686400 像素**（`2048x2048`） |
| 参考图 | ❌ 不支持 | ✅ `ref_image`（base64） |
| 组图模式 | ❌ 不支持 | ✅ `sequential_image_generation` |
| 文字嵌入 | 通过提示词指令 | 通过提示词指令 |
| 角色一致性 | 依赖固定描述 | 参考图 + 组图模式显著更优 |

## 文字嵌入规范

### 核心原则
- 每页插图提示词中**务必包含该页的完整文字**，让 Seedream 将文字直接渲染在图像中
- 文字使用**用户指定的原始语言**（中文/英文/葡文等）写入提示词
- 不使用 PDF 脚本的文字嵌入作为主要方式，而是依赖 Seedream 的文字渲染能力

### ⚠️ 强制文字嵌入指令格式

在每页提示词中，**必须使用以下强制指令格式**嵌入文字：

```
务必把「{该页文字原文}」的文字嵌入图片中，渲染为可爱的圆角{文字颜色}字体，位于画面底部居中位置，带柔和文字阴影以确保可读性。文字区域使用柔和渐变背景。
```

**示例**（中文单语）：
```
务必把「小兔子找到了一个红苹果」的文字嵌入图片中，渲染为可爱的圆角深棕色字体，位于画面底部居中位置，带柔和白色文字阴影以确保可读性。文字区域使用柔和的浅色渐变背景。
```

**示例**（中英双语）：
```
务必把「小兔子找到了一个红苹果」和「Little rabbit found a red apple」的文字嵌入图片中，分两行显示于画面底部居中位置：第一行为中文（较大字号），第二行为英文（较小字号）。使用可爱的圆角深棕色字体，带柔和白色文字阴影，文字区域使用柔和渐变背景。
```

### 文字颜色选择
根据页面背景亮度，在提示词中指定文字颜色：

```
# 亮色背景（白天、室内明亮场景）
... rendered in cute rounded dark brown font ...
# 或
... rendered in cute rounded dark gray font ...

# 暗色背景（夜晚、星空、森林深处）
... rendered in cute rounded white font ...
# 或
... rendered in cute rounded soft yellow font ...
```

### 双语文字排版
双语版本需在提示词中使用如下强制指令格式：

```
务必把「{第一语言文字}」和「{第二语言文字}」的文字嵌入图片中，分两行显示于画面底部居中位置：第一行{第一语言}（较大字号），第二行{第二语言}（较小字号）。使用可爱的圆角{文字颜色}字体，带柔和文字阴影，文字区域使用柔和渐变背景。
```

### 葡萄牙文特殊注意事项
- 葡萄牙文含重音符号（ã, é, ç 等），在提示词中保留原文拼写
- 如 Seedream 对葡萄牙文渲染不佳，可在提示词中额外说明 "render the text accurately with correct diacritics"
- 葡文通常较长，需考虑字号适当缩小或使用更宽的文字区域（底部 25%）
